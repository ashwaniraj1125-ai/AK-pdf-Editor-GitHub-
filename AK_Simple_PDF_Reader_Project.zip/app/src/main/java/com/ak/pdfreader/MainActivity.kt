package com.ak.pdfreader

import android.app.Activity
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.pdf.PdfRenderer
import android.net.Uri
import android.os.Bundle
import android.os.ParcelFileDescriptor
import android.view.Gravity
import android.view.ViewGroup
import android.widget.Button
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast

class MainActivity : Activity() {
    private lateinit var preview: ImageView
    private lateinit var pageLabel: TextView
    private var pfd: ParcelFileDescriptor? = null
    private var pdf: PdfRenderer? = null
    private var page = 0

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(14, 14, 14, 14)
        }
        root.addView(TextView(this).apply {
            text = "AK PDF Reader"; textSize = 25f; gravity = Gravity.CENTER
            setPadding(0, 8, 0, 12)
        })
        root.addView(Button(this).apply {
            text = "Open PDF"
            setOnClickListener {
                val i = Intent(Intent.ACTION_OPEN_DOCUMENT).apply {
                    addCategory(Intent.CATEGORY_OPENABLE); type = "application/pdf"
                }
                startActivityForResult(i, 42)
            }
        })
        pageLabel = TextView(this).apply {
            text = "No PDF opened"; textSize = 16f; gravity = Gravity.CENTER
            setPadding(0, 10, 0, 10)
        }
        root.addView(pageLabel)
        preview = ImageView(this).apply { adjustViewBounds = true; scaleType = ImageView.ScaleType.FIT_CENTER }
        root.addView(preview, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f))
        val row = LinearLayout(this).apply { gravity = Gravity.CENTER }
        row.addView(Button(this).apply { text = "◀ Previous"; setOnClickListener { render(page - 1) } },
            LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
        row.addView(Button(this).apply { text = "Next ▶"; setOnClickListener { render(page + 1) } },
            LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
        root.addView(row)
        setContentView(root)
    }

    @Deprecated("Legacy activity result callback")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == 42 && resultCode == RESULT_OK) {
            try {
                closePdf()
                val uri: Uri = data?.data ?: return
                pfd = contentResolver.openFileDescriptor(uri, "r")
                pdf = PdfRenderer(pfd!!)
                render(0)
            } catch (e: Exception) {
                Toast.makeText(this, "PDF open nahi hua: ${e.message}", Toast.LENGTH_LONG).show()
            }
        }
    }

    private fun render(index: Int) {
        val doc = pdf ?: run {
            Toast.makeText(this, "Pehle PDF open karein", Toast.LENGTH_SHORT).show(); return
        }
        if (index !in 0 until doc.pageCount) {
            Toast.makeText(this, "Aur page nahi hai", Toast.LENGTH_SHORT).show(); return
        }
        try {
            doc.openPage(index).use { pg ->
                val bmp = Bitmap.createBitmap(pg.width * 2, pg.height * 2, Bitmap.Config.ARGB_8888)
                pg.render(bmp, null, null, PdfRenderer.Page.RENDER_MODE_FOR_DISPLAY)
                preview.setImageBitmap(bmp)
            }
            page = index
            pageLabel.text = "Page ${page + 1} / ${doc.pageCount}"
        } catch (e: Exception) {
            Toast.makeText(this, "Page error: ${e.message}", Toast.LENGTH_LONG).show()
        }
    }

    private fun closePdf() {
        pdf?.close(); pdf = null
        pfd?.close(); pfd = null
    }

    override fun onDestroy() { closePdf(); super.onDestroy() }
}
